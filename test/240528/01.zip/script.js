const UploadImg = document.querySelector(".upload_img");
const DropImg = document.querySelector(".drop_img");
console.log(UploadImg, DropImg);

UploadImg.addEventListener("drag", () => {
  
});
