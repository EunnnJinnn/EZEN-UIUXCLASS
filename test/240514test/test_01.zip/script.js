// 1. 텍스트, 트윗하기을 인식
// 2. 텍스트에 값을 입력하면 인식해야함
// 3. 인식한 값을 쿼리값으로 바꿔야함
// 4. 입력된 값을 트윗하기 버튼을 누르면 주소창에 쿼리값으로 변경된 후 트위터 창으로 가야함

const userText = document.querySelector(".user_text");
const submitBtn = document.querySelector(".submit_btn");
console.log(userText, submitBtn);

form.addEventListener("click", (e) => {
  link = "https://twitter.com/";
});
